SITE DE MINI-FORMATION POWER BI — MODE D’EMPLOI

1. Décompressez le ZIP.
2. Ouvrez le dossier mini_formation_power_bi_site.
3. Copiez votre vidéo dans le dossier assets.
4. Renommez-la formation-power-bi.mp4.
5. Ouvrez index.html dans votre navigateur : la vidéo doit apparaître dans la section « Vidéo ».

LIGNE HTML À MODIFIER SI LE NOM DE VOTRE VIDÉO EST DIFFÉRENT
-----------------------------------------------------------
Dans index.html, cherchez (Ctrl+F) :
    <source src="assets/formation-power-bi.mp4" type="video/mp4">

Exemple si votre fichier s’appelle ma-video.mp4 :
    <source src="assets/ma-video.mp4" type="video/mp4">

La ligne est dans la section marquée :
    <!-- VIDEO A AJOUTER ICI : remplacez le fichier src si votre vidéo porte un autre nom -->

CONSEILS
- Préférez une vidéo MP4 encodée en H.264 pour une bonne compatibilité.
- Gardez la vidéo dans le dossier assets pour que le chemin relatif fonctionne.
- Le lecteur HTML5 est déjà présent et les commandes de lecture sont activées.
- Pour publier en ligne, téléversez tout le dossier avec index.html et assets ensemble.
- Le site est une maquette : le paiement et le téléchargement du support PDF ne sont pas encore connectés.
